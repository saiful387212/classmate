(function () {
    const root = document.getElementById('batchChat');
    if (!root) return;

    const list = document.getElementById('batchChatMessages');
    const status = document.getElementById('batchChatStatus');
    const form = document.getElementById('batchChatForm');
    const input = document.getElementById('batchChatInput');
    const sendButton = document.getElementById('batchChatSend');
    const endpoint = root.dataset.endpoint;
    const csrfToken = root.dataset.csrf;
    let lastId = 0;
    let isLoading = false;
    let isSending = false;

    function appendMessage(message) {
        if (status) status.remove();

        const item = document.createElement('article');
        item.className = 'batch-chat-message' + (message.sender_type === 'student' ? ' is-student' : ' is-admin');

        const meta = document.createElement('div');
        meta.className = 'batch-chat-message-meta';

        const author = document.createElement('strong');
        author.textContent = message.sender_name || 'Batch member';
        meta.appendChild(author);

        const role = document.createElement('span');
        role.className = 'batch-chat-role';
        role.textContent = message.sender_type === 'admin' ? 'Admin' : 'Student';
        meta.appendChild(role);

        const time = document.createElement('time');
        time.dateTime = message.created_at;
        const parsedDate = new Date(String(message.created_at).replace(' ', 'T'));
        time.textContent = Number.isNaN(parsedDate.getTime())
            ? ''
            : parsedDate.toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
        meta.appendChild(time);

        const content = document.createElement('p');
        content.className = 'batch-chat-message-content';
        content.textContent = message.content;

        item.append(meta, content);
        list.appendChild(item);
        lastId = Math.max(lastId, Number(message.id) || 0);

        while (list.children.length > 250) {
            list.removeChild(list.firstElementChild);
        }
    }

    async function loadMessages(initial) {
        if (isLoading) return;
        isLoading = true;
        const wasNearBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 100;

        try {
            const response = await fetch(endpoint + '?action=messages&after=' + (initial ? 0 : lastId), {
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { Accept: 'application/json' }
            });
            const result = await response.json();
            if (!response.ok || !result.success) {
                throw new Error(result.message || 'Unable to load batch messages.');
            }

            if (!result.messages.length && initial && status) {
                status.textContent = 'No messages yet. Start the conversation!';
            } else {
                result.messages.forEach(appendMessage);
            }
            if (status.classList.contains('batch-chat-error')) {
                if (lastId > 0) {
                    status.remove();
                } else {
                    status.textContent = 'No messages yet. Start the conversation!';
                    status.classList.remove('batch-chat-error');
                }
            }

            if (wasNearBottom || initial) {
                list.scrollTop = list.scrollHeight;
            }
        } catch (error) {
            if (status) {
                status.textContent = error.message || 'Unable to load batch messages. Please retry.';
                status.classList.add('batch-chat-error');
                if (!status.isConnected) list.prepend(status);
            }
        } finally {
            isLoading = false;
        }
    }

    form.addEventListener('submit', async function (event) {
        event.preventDefault();
        const content = input.value.trim();
        if (!content || isSending) return;

        isSending = true;
        sendButton.disabled = true;
        try {
            const response = await fetch(endpoint + '?action=send', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                },
                body: JSON.stringify({ content: content, csrf_token: csrfToken })
            });
            const result = await response.json();
            if (!response.ok || !result.success) {
                throw new Error(result.message || 'Unable to send your message.');
            }

            input.value = '';
            await loadMessages(false);
            input.focus();
        } catch (error) {
            if (status) {
                status.textContent = error.message || 'Unable to send your message. Please try again.';
                status.classList.add('batch-chat-error');
                list.prepend(status);
            } else {
                const message = document.createElement('p');
                message.className = 'batch-chat-status batch-chat-error';
                message.textContent = error.message || 'Unable to send your message. Please try again.';
                list.prepend(message);
            }
        } finally {
            isSending = false;
            sendButton.disabled = false;
        }
    });

    input.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            form.requestSubmit();
        }
    });

    loadMessages(true);
    window.setInterval(function () {
        if (!document.hidden) loadMessages(false);
    }, 4000);
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) loadMessages(false);
    });
})();
