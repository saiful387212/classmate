<?php
require_once __DIR__ . '/config.php';
require_once BASE_PATH . '/includes/auth-middleware.php';

$userType = Session::get('user_type');
$batchId = (int)($currentUser['batch_id'] ?? 0);

if (!in_array($userType, ['student', 'admin'], true) || $batchId <= 0) {
    Session::setFlash('error', 'Batch chat is only available to users assigned to a batch.');
    header('Location: ' . ($userType === 'admin' ? url('admin/dashboard.php') : url('student/dashboard.php')));
    exit;
}

$db = Database::getInstance();
$stmt = $db->prepare('SELECT COALESCE(label, CONCAT("Batch ", name)) FROM batches WHERE id = ? LIMIT 1');
$stmt->execute([$batchId]);
$batchName = $stmt->fetchColumn() ?: 'Your batch';

$pageTitle = 'Batch Chat';
$pageCss = 'batch-chat.css';
$pageJs = 'batch-chat.js';
$chatEndpoint = url('api/batch-chat.php');
$csrfToken = Security::generateCSRFToken();
include_once BASE_PATH . '/includes/header.php';
?>

<section class="batch-chat-page">
    <header class="batch-chat-header">
        <div>
            <p class="batch-chat-eyebrow"><i class="fas fa-users"></i> <?php echo htmlspecialchars($batchName, ENT_QUOTES, 'UTF-8'); ?></p>
            <h1>Batch Chat</h1>
            <p>Discuss classes, share ideas, and help each other out.</p>
        </div>
        <span class="batch-chat-live"><span></span> Live chat</span>
    </header>

    <div
        class="batch-chat-panel"
        id="batchChat"
        data-endpoint="<?php echo htmlspecialchars($chatEndpoint, ENT_QUOTES, 'UTF-8'); ?>"
        data-csrf="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>"
        aria-label="Batch chat"
    >
        <div class="batch-chat-messages" id="batchChatMessages" role="log" aria-live="polite" aria-relevant="additions">
            <p class="batch-chat-status" id="batchChatStatus">Loading messages...</p>
        </div>
        <form class="batch-chat-form" id="batchChatForm">
            <label class="sr-only" for="batchChatInput">Write a message</label>
            <textarea id="batchChatInput" name="content" rows="2" maxlength="2000" placeholder="Write a message to your batch..." required></textarea>
            <div class="batch-chat-form-footer">
                <span>Enter to send · Shift + Enter for a new line</span>
                <button class="btn btn-primary" type="submit" id="batchChatSend">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </div>
        </form>
    </div>
</section>

<?php include_once BASE_PATH . '/includes/footer.php'; ?>
